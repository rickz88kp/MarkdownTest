---
layout: post
title:  Poetry on Platforms
date:   2015-06-16
permalink: /exhibitions/online-exhibitions/test2
---
![banner](/images/POP07-191x300.jpg)

Immerse yourself in 82 Singapore poems written beautifully by poets on the City Hall MRT platforms. Commuters and passer-by can look forward to humorous, moving and thought-provoking poems on life, people, and places in Singapore that will strike a chord with them

Commuters are required to pay applicable fare upon entry and exit from fare gates at SMRT stations.
